/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sk.jasku.kocky;

import java.awt.Graphics;

/**
 *
 * @author Tomas
 */
public abstract class Utvar {
    protected int x,y;
    protected final int w,h;
    protected final Graphics g;
    public Utvar(int x,int y, int w, int h,Graphics g){
        
    }
    protected void nastavX(int x){
        this.x = x;
        prekresli();
    }
    protected void nastavY(int y){
        this.y = y;
        prekresli();
    }
    protected void nastavXY(int x, int y){
        nastavX(x);
        nastavY(y);
    }
    protected void prekresli(){
        g.clearRect(0, 0, 1024, h);
        g.drawRect(x, y, w, h);
    }

}
