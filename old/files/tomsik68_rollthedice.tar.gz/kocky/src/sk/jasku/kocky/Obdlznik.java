/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sk.jasku.kocky;

import java.awt.Graphics;

/**
 *
 * @author Tomas
 */
public abstract class Obdlznik extends Utvar{

    public Obdlznik(int x, int y,int w, int h, Graphics g){
        
    }



}
