#include <nds.h>
void wait(int secs){
int i = 0;
//Convert secs to DS's format
// (DS runs @ 60 FPS)
secs *= 60;
for (;i<=secs;i++){
	swiWaitForVBlank();
}
}
