#include <nds.h>
#include <stdio.h>
#include <time.h>
#include <fat.h>
#include "basewifi.h"

//---------------------------------------------------------------------------------
int main(void) {
	fatInitDefault();
	FILE*dbgfile = fopen("netchecker.log","a+");
	const int chkmins = 1;
	bool online = true;
//---------------------------------------------------------------------------------
	consoleDemoInit();
	iprintf("NetChecker v0.1\nChecking connectivity every %i minutes.",chkmins);
	
	int hours,minutes,seconds = 0;
	while(true) {
//get time
        time_t unixTime = time(NULL);
        struct tm* timeStruct = gmtime((const time_t *)&unixTime);
        hours = timeStruct->tm_hour;
        minutes = timeStruct->tm_min;
        seconds = timeStruct->tm_sec;
//check net
		Wifi_EnableWifi();
		online = Wifi_InitDefault(WFC_CONNECT);
		Wifi_DisableWifi();
//write to file
		fprintf(dbgfile,"[%i:%i:%i] %s \n",hours,minutes,seconds,online ? "online" : "offline");
		scanKeys();
//if A is pressed, exit
		if(keysDown() & KEY_A){
			fclose(dbgfile);
			iprintf("You can shutdown now...");
		}
		iprintf("[%i:%i:%i] %s\n",hours,minutes,seconds,online ? "online" : "offline");
		wait(chkmins * 60);
	}
	return 0;
}

