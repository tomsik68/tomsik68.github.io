﻿Public Class Form1
    Dim userName As String
    Dim password As Char()
#Const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuwvxyz0123456789"
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.WindowState = FormWindowState.Minimized
        userName = TextBox1.Text
        For i As Integer = 0 To 60
            My.Computer.Keyboard.SendKeys(userName)
            My.Computer.Keyboard.SendKeys("{TAB}")
            password(1) = 
            My.Computer.Keyboard.SendKeys(password)

        Next
    End Sub
End Class
