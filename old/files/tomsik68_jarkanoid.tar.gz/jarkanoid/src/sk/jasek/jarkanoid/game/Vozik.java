/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sk.jasek.jarkanoid.game;

import java.awt.Color;
import java.awt.Graphics;
import sk.jasek.jarkanoid.game.Plocha.SMER;

/**
 *
 * @author Tomas
 */
public class Vozik {
    private int x,y;
    private final Graphics g;
    private final int SCR_HEIGHT;
    private final int SCR_WIDTH;
    private final int HEIGHT = 15;
    private final int WIDTH = 60;

    public Vozik(int x,int y,Plocha p){
        this.x = x;
        this.y = y;
        this.g = p.getGraphics();
        this.SCR_HEIGHT = p.getHeight();
        this.SCR_WIDTH = p.getWidth();
    }

    public void paint(){
        g.setColor(Color.white);
        g.fillRect(x-5, y, WIDTH+10, HEIGHT);
        g.setColor(Color.green);
        g.fillRoundRect(x, y, WIDTH, HEIGHT,5,5);
    }

    void posun(SMER smer) {
        if(smer == Plocha.SMER.POSUN_VLAVO)
            x = x-5;
        if(smer == Plocha.SMER.POSUN_VPRAVO)
            x = x+5;
        paint();
    }
}

