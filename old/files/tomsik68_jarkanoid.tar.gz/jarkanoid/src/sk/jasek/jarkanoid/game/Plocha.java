/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sk.jasek.jarkanoid.game;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

/**
 *
 * @author Tomas
 */
public class Plocha extends Canvas{

    private final ArrayList<Lopticka> lopticky = new ArrayList<Lopticka>();
    private Vozik vozik;
    public enum SMER{
             POSUN_VLAVO,POSUN_VPRAVO
    }
    public Plocha(){

    }
    public void init(){
        vozik = new Vozik(50, getHeight()-50 ,this);
        createBufferStrategy(2);
        Lopticka lopticka = new Lopticka(50, 50 ,this);
        lopticky.add(lopticka);
        lopticka.start();
        addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {
                int keyCode = evt.getKeyCode();
                switch(keyCode){
                    case KeyEvent.VK_LEFT:
                        vozik.posun(SMER.POSUN_VLAVO);
                    break;
                    case KeyEvent.VK_RIGHT:
                        vozik.posun(SMER.POSUN_VPRAVO);
                    break;

        }
            }
        });
    }
        @Override
    public void paint( Graphics g) {
        g.setColor(Color.white);
        int SCR_HEIGHT = getHeight();
        int SCR_WIDTH = getWidth();
        g.fillRect(0, 0, SCR_WIDTH, SCR_HEIGHT);
        if(vozik != null)
            vozik.paint();
    }

}
