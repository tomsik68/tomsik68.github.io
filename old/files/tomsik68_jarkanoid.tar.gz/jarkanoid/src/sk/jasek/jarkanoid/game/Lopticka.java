/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sk.jasek.jarkanoid.game;

import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tomas
 */
class Lopticka extends Thread{
    private float x,y;
    private float xvel,yvel,alpha;
    private final Graphics g;
    private final Plocha plocha;
    private final int HEIGHT = 15;
    private final int WIDTH = 15;
    private final int SCR_HEIGHT;
    private final int SCR_WIDTH ;
    private final int MIN_DELAY = 2 ;
    private boolean loptickaSpadla = false;
    
    public Lopticka(int x,int y,Plocha p){
        super();
        this.x = x;
        this.y = y;
        this.g = p.getGraphics();
        this.SCR_HEIGHT = p.getHeight();
        this.SCR_WIDTH = p.getWidth();
        this.plocha = p;
        setAlpha((float)Math.PI / 4);
    }

    private void setAlpha(float value){
        alpha = value;
        xvel = (float)Math.cos(alpha)*2;
        yvel = (float)Math.sin(alpha)*2;
    }

    public void paint(){
        g.setColor(Color.white);
        g.fillOval( (int)(x-xvel), (int)(y-yvel), WIDTH, HEIGHT);
        g.setColor(Color.red);
        g.fillOval((int)x, (int)y, WIDTH, HEIGHT);
    }
    
    @Override
    public void run() {
        loptickaSpadla = false;
        int delay = 10;
        int counter = 0;
        try {
            while(!loptickaSpadla){
                x= x+ xvel;
                y= y+ yvel;
                paint();
                if ( x >= SCR_WIDTH - WIDTH || x <= 0){
                    xvel *= -1;
                }
                if (y <= 0){
                    yvel *= -1;
                }
                if ( y >= SCR_HEIGHT - HEIGHT){
                    loptickaSpadla = true;
                }
                if( counter++ == 1000 ){
                    counter = 0;
                    if(delay != MIN_DELAY)
                        delay--;
                }
                    sleep(delay);
        }
        } catch (InterruptedException ex) {
             Logger.getLogger(Lopticka.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
}

