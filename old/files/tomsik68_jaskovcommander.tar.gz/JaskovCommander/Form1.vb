﻿Public Class Form1
    Dim stuff As String
    Dim sav As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            OpenFileDialog1.ShowDialog()
            stuff = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName)
            TextBox1.Text = stuff
        Catch ex As Exception
            MsgBox("Chyba:Vyberte nejaky subor,ktory mam otvorit")
        Finally
            TextBox1.Text = stuff
        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            sav = TextBox1.Text
        Catch ex As Exception
            MsgBox("Musite zadat nejaky text aby sa dokument mohol ulozit")
        Finally
            SaveFileDialog1.ShowDialog()
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName(), sav, True)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Text = ""
    End Sub

End Class
