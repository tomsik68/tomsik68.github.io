﻿Module Module1
    Dim scpath As String
    Dim cdname As String
    Dim bw As String
    Sub continueBW()
        Console.WriteLine("Please wait until the proccess finishes.It could take a few minutes...")
        Dim tmp As String
        tmp = cdname & ":/INSTALL.EXE"
        If scpath.EndsWith("/") Then
            My.Computer.FileSystem.CopyFile(tmp, scpath & "BroodWar.mpq")
        Else
            My.Computer.FileSystem.CopyFile(tmp, scpath & "/BroodWar.mpq")
        End If

        Console.WriteLine("Proccess finished.Enjoy!")
    End Sub
    Sub continueSC()
        Console.WriteLine("Please wait until the proccess finishes.It could take a few minutes...")
        Dim tmp As String
        tmp = cdname & ":/INSTALL.EXE"
        If scpath.EndsWith("/") Then
            My.Computer.FileSystem.CopyFile(tmp, scpath & "StarCraft.mpq")
        Else
            My.Computer.FileSystem.CopyFile(tmp, scpath & "/StarCraft.mpq")
        End If
        Console.WriteLine("Proccess finished.Enjoy!")
    End Sub
    Sub Main()
        Console.Title = "StarCraft patcher"
        Console.WriteLine("Note:Before patching,you need:")
        Console.WriteLine("1.)Original StarCraft")
        Console.WriteLine("2.)Original StarCraft or BroodWar CD")
        Console.WriteLine("Please enter path to StarCraft")
        scpath = Console.ReadLine()
        Console.WriteLine("You entered: " & scpath)
        Console.WriteLine("Please insert StarCraft/BroodWar CD into CD drive and enter OK")
        While Not Console.ReadLine.ToLower = "ok"

        End While
        Console.WriteLine("Please enter your CD drive letter(it's found in My Computer")
        cdname = Console.ReadLine()
        Console.WriteLine("Do you have Broodwar expansion?")
        bw = Console.ReadLine()
        If bw = "yes" Then
            continueBW()
        ElseIf bw = "no" Then
            continueSC()
        Else
            Console.WriteLine("please answer yes or no")
        End If
        While Not Console.ReadLine = "exit"

        End While
    End Sub
End Module
