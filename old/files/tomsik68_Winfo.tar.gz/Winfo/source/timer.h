#include <nds.h>
void wait(int msecs){
for (int i=0;i<=msecs;i++){
swiWaitForVBlank();
}
}
