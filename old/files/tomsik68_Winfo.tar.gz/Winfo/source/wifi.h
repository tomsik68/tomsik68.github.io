#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include "timer.h"
#include "httpget.h"

char * achacha(char*array,char*to_append){
	int arsiz1 = sizeof(array);
	arsiz1 += 1;
	const int arsiz2 = sizeof(to_append);
	iprintf("Size of array is:%d \n Size of array to append is: %d",arsiz1,arsiz2);
	for(int i =0;i<=arsiz2;i++){
		arsiz1 = sizeof(array);
		array[arsiz1+i]  = to_append[i];
		iprintf("array[%d] = to_append[%d];",arsiz1+i,i);
	}
return array;
}

void Wifi_displayApInfo(Wifi_AccessPoint ap){
consoleClear();
iprintf("SSID:%s \n Encryption:%s \n Sig:%i\n Network type:%s \n",
   				ap.ssid,
				ap.flags & WFLAG_APDATA_WEP ? "WEP " : WFLAG_APDATA_WPA ? "WPA " : "No",
				ap.rssi * 100 / 0xD0,
                WFLAG_APDATA_ADHOC ? "Infrastructure" : "Ad-hoc");
}

Wifi_AccessPoint Wifi_UserSelectAP(void){
	//---------------------------------------------------------------------------------

	int selected = 0;
	int i;
	int count = 0;

	static Wifi_AccessPoint ap;

	Wifi_ScanMode(); //this allows us to search for APs

	while(!(keysDown() & KEY_A))
	{
		scanKeys();

		//find out how many APs there are in the area
		count = Wifi_GetNumAP();

		consoleClear();

		iprintf("Number of APs found: %d\n", count);

		//display the APs to the user
		for(i = 0; i < count; i++)
		{
			Wifi_AccessPoint ap;

			Wifi_GetAPData(i, &ap);
			// display the name of the AP
			iprintf("%s %s Lock:%s Sig:%i\n",
				selected == i ? ">" : "*",
				ap.ssid,
				ap.flags & WFLAG_APDATA_WEP ? "WEP " : WFLAG_APDATA_WPA ? "WPA" : "None",
				ap.rssi * 100 / 0xD0);

		}

		//move the selection asterick
		if(keysDown() & KEY_UP)
		{
			selected--;
			if(selected < 0)
			{
				selected = 0;
			}
		}

		if(keysDown()&KEY_DOWN)
		{
			selected++;
			if(selected >= count)
			{
				selected = count - 1;
			}
		}
	wait(5);
 	}

	//user has made a choice so grab the ap and return it
	Wifi_GetAPData(selected, &ap);

	return ap;
}


void Wifi_ListAp(int selected){
	int i;
	int count = 0;
	char ** apName;
	Wifi_AccessPoint temp;
	Wifi_ScanMode(); //this allows us to search for APs
	//find out how many APs there are in the area
	count = Wifi_GetNumAP();
	//display the APs to the user
	iprintf("SSID | Encryption | Signal \n");
	for(i = 0; i < count; i++)
	{
			Wifi_GetAPData(i, &temp);
			iprintf(" |%s| %s | %s | %d \n",selected == i ? ">" : "*",temp.ssid,temp.flags & WFLAG_APDATA_WEP ? "WEP" : WFLAG_APDATA_WPA ? "WPA" : "None",temp.rssi * 100 / 0xD0);

	}
}
bool Wifi_HasInternet(Wifi_AccessPoint ap){
unsigned char*key;
key = "";
Wifi_ConnectAP(&ap,WEPMODE_NONE,0,key);

}
bool Wifi_isEncrypted(Wifi_AccessPoint ap){
if(ap.flags && WFLAG_APDATA_WEP)
return true;
}else return false;
}



