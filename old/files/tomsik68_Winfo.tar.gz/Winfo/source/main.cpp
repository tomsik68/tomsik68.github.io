#include <nds.h>
#include <stdio.h>
#include "wifi.h"
int main(void)
{
	Wifi_AccessPoint ap;
	int selected=0;
	int cAP;
	consoleDemoInit();
 	Wifi_InitDefault(true);
	Wifi_EnableWifi();
	while(1)
	{
		consoleClear();
		ap = Wifi_UserSelectAP();
		while(!(keysDown() & KEY_B)){
            Wifi_displayApInfo(ap);
			wait(5);
			scanKeys();
		}
	}

	return 0;
}

