#include <nds.h>
#include "wifi.h"
#include <stdio.h>
int main(){
    
	while(true){
		while(keysDown() & ~KEY_A){
			scanKeys();
		}
        getData();
	}
	return 0;
}
void getData(){
	consoleDemoInit();
	consoleClear();
	Wifi_EnableWifi();
	bool wifi = Wifi_InitDefault(true);
	if(!wifi) {
		iprintf("Wifi connection failed \n");
		return 1;
	}
    // Find the IP address of the server, with gethostbyname
	char* host = "212.89.228.166";
    struct hostent * myhost = gethostbyname(host);
    iprintf("Found IP Address!\n");

    // Create a TCP socket
    int my_socket;
    my_socket = socket(AF_INET, SOCK_DGRAM, 0 );
    iprintf("Created Socket!\n");

    // Tell the socket to connect to the IP address we found, on port 80 (HTTP)
    struct sockaddr_in sain;
    sain.sin_family = AF_INET;
    sain.sin_port = htons(25565);
    sain.sin_addr.s_addr= *( (unsigned long *)(myhost->h_addr_list[0]) );
	iprintf("Host IP: %l\n",sain.sin_addr.s_addr);
    if(connect( my_socket,(struct sockaddr *)&sain, sizeof(sain) ) == -1){
		iprintf("Server connection failed \n");
		return;
	}
    iprintf("Connected to server!\n");
	// ping server with 254
	int result = send(my_socket,254,1,0);
	if(result == -1){
		iprintf("Ping failed.\n");
		return;
	}
	iprintf("Waiting for answer... \n");
	u8 b;
	while(recv(my_socket,b,1,0) == 0){}
	if(b != 255){
		iprintf("Received invalid packet with id: %s\n",b);
	}
	char buffer;
	while(recv(my_socket,buffer,1,0) == 1){
		if(buffer == '�') iprintf("\n");
		else{
			iprintf("%s",buffer);
		}
	}
	
	
	iprintf("End of Stream");
	closesocket(my_socket);
}
