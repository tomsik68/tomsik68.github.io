/* ***LEVEL TEMMPLATE ***
int level(){
   u8 objno;
   //treba zmazat vsetky objekty z minuleho levelu,ak sa chystam vytvorit nove,netreba vyuzit tuto cast kodu
   for (objno=2;objno<=6;objno++){
      PA_DeleteSprite(1,objno);
   }   
   defaultVars();
   //design levelu(PA_CreateSprite();)
	while(!checkCollision(x,y,1247,12,32,32,32,32)){
	   //level logic
	   controlLoop();
	}   
	levelCompleted();
	return 0;
}   
*/
//X = 1008-1264
//Y = 173-990--17
#include <PA9.h>
//gfx
#include "gfx/all_gfx.c"
#include "gfx/all_gfx.h"
#include "include/rectangleCollision.h"
#include "include/Y.h"
//strany kolizie
#define LEFT 0
#define RIGHT 1
#define UP 2
#define DOWN 3
//premenne
s16 x=1021;
s16 y=161;
//***JASKOVE DABELSKE FUNKCIE***
void collisionWall(u8 screen,u8 obj1,u8 obj2){
      s16 xs1,xs2,ys1,ys2;
      xs1=PA_GetSpriteX(screen,obj1);
      xs2=PA_GetSpriteX(screen,obj2);
      ys1=PA_GetSpriteY(screen,obj1);
      ys2=PA_GetSpriteY(screen,obj2);
      if(checkCollision(xs1,ys1,xs2-8,ys2,32,32,1,32))x-=8; //lava strana
      if(checkCollision(xs1,ys1,xs2+8,ys2,32,32,1,32))x+=8; //prava strana
      if(checkCollision(xs1,ys1,xs2,ys2+8,32,32,32,1))y+=8; //hore
      if(checkCollision(xs1,ys1,xs2,ys2-8,32,32,32,1))y-=8; //dole
}	   
//tato funkcia zisti,ci sa auto nezraza s nejakym objektom,ktory je len obrazok... :)
//w a h su na urcenie vysky a dlzky obr. objektu,ktory na tom nejak obmedzeny nie je
void collisionWater(u8 waterNo){
   	s16 xs1,ys1,xs2,ys2;
   	u8 w,h;
   	w,h=32;
   	xs1=PA_GetSpriteX(1,0);
   	ys1=PA_GetSpriteY(1,0);
   	xs2=PA_GetSpriteX(1,waterNo);
   	ys2=PA_GetSpriteY(1,waterNo);
      if(checkCollision(xs1,ys1,xs2-w/2,ys2,32,32,1,32)){
		defaultVars();
		levelCompleted();//lava strana
}		
      if(checkCollision(xs1,ys1,xs2+w/2,ys2,32,32,1,w)){
  		defaultVars();
		levelCompleted();
}		

      if(checkCollision(xs1,ys1,xs2,ys2+h/2,32,32,h,1)){
  		defaultVars();
		levelCompleted();
}		
      if(checkCollision(xs1,ys1,xs2,ys2-h/2,32,32,h,1)){
  		defaultVars();
		levelCompleted();
}		
}
void levelCompleted(){
   	int i;
   	for(i = 0; i > -32; i--){
		PA_SetBrightness(0, i); 
		PA_SetBrightness(1, i); 
		PA_WaitForVBL();		   
	}  	
	//casovanie
	s16 time = 180; // 180 frames = 3 seconds
	while(time && (!Pad.Newpress.Anykey) && (!Stylus.Newpress)){ // Display until time over or keys pressed
		time--; // time goes by
		PA_WaitForVBL();
	}		
	for(i = -31; i <= 0; i++){
		PA_SetBrightness(0, i); 
		PA_SetBrightness(1, i); 
		PA_WaitForVBL();		   
}
defaultVars();
}   
void defaultVars(void){
x=1021;
y=161;
}
void controlLoop(){
		if(Pad.Held.Right)x+=1;
		if(Pad.Held.Left)x-=1;
		if(Pad.Held.Up)y-=1;
		if(Pad.Held.Down)y+=1;
		
		// Set the sprite's position
		PA_SetSpriteXY(1, // screen
					   0, // sprite
					   x, // x position
					   y); // y...
  		PA_OutputText(0,0,0,"carX:%d",PA_GetSpriteX(1,0));
		PA_OutputText(0,0,1,"carY:%d",PA_GetSpriteY(1,0));
		PA_WaitForVBL();
 }   
//***LEVELY***
int level0(){
   while (!checkCollision(x,y,1247,12,32,32,32,32)){
      controlLoop();
		PA_OutputText(0,0,0,"carX:%d",x);
		PA_OutputText(0,0,1,"carY:%d",y);
		}   
	levelCompleted();
   return 0;
}   
int level1(){
   u8 objno;
	PA_CreateSprite(1,2,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1200,160);
	PA_CreateSprite(1,3,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1200,128);
	PA_CreateSprite(1,4,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1200,96);
	PA_CreateSprite(1,5,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1200,64);
	PA_CreateSprite(1,6,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1200,32);
   
	while (!checkCollision(x,y,1247,12,32,32,32,32)){
      controlLoop();
      for(objno=2;objno<=6;objno++){
      collisionWall(1,0,objno);
   	}   
		PA_OutputText(0,0,0,"carX:%d",PA_GetSpriteX(1,0));
		PA_OutputText(0,0,1,"carY:%d",PA_GetSpriteY(1,0));
	}
 levelCompleted();
 return 0;  
}   
int level2(){
   //auto sa musi vratit domov :)
   defaultVars();
	u8 objno;
	u16 tmpy[6];
	tmpy[2]=160;
	tmpy[3]=128;
	tmpy[4]=96;
	tmpy[5]=64;
	tmpy[6]=32;
	//az tu kreslim level
   PA_CreateSprite(1,2,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1200,160);
   PA_CreateSprite(1,3,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1200,128);
   PA_CreateSprite(1,4,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1200,96);
   PA_CreateSprite(1,5,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1200,64);
   PA_CreateSprite(1,6,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1200,32);
   while (!checkCollision(x,y,1247,12,32,32,32,32)){
      controlLoop();//standardny loop(ovladanie)
      //kontrolujem,ci sa auto nezraza s vodou
      for(objno=2;objno<=6;objno++){
      	if(checkCollision(x,y,1200,tmpy[objno],32,32,32,32)){
      	   defaultVars();
         	levelCompleted();
   		}   
 		}  	
 		//vypisujem X a Y

	   
	}
levelCompleted();
return 0;
}		   
int level3(){
   u8 objno;
   defaultVars();
   //design levelu
   PA_CreateSprite(1,2,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1056,161);
   PA_CreateSprite(1,3,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1056,129);
   PA_CreateSprite(1,4,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1056,880);
   PA_CreateSprite(1,5,(void*)water_Sprite,OBJ_SIZE_32X32,1,0,1056,730);
   PA_CreateSprite(1,6,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1056,738);
   PA_CreateSprite(1,7,(void*)wall_Sprite,OBJ_SIZE_32X32,1,0,1056,706);
	while(!checkCollision(x,y,1247,12,32,32,32,32)){
	   //level logic
	   collisionWall(1,0,2);
	   for (objno=3;objno<=6;objno++){
	      collisionWater(objno);
	   }   
	   controlLoop();
	}   
	levelCompleted();
	return 0;
}   
//main
int main(){
   //inicializacia
   PA_Init();
   PA_InitText(0,0);
   PA_EasyBgLoad(1,0,grass);
   //paleta pre auto
   PA_LoadSpritePal(1,0,(void*)Jaskova_Pal);
   //SPRITY
   //auto
	PA_CreateSprite(1,0,(void*)car_Sprite,OBJ_SIZE_32X32,1,0,x,y);
	//ciel
	PA_CreateSprite(1,1,(void*)coin_Sprite,OBJ_SIZE_32X32,1,0,1247,12);
	//hra
	level0();
	level1();
	level2();
	level3();
	while(1){
	}	
	return 0;
}
