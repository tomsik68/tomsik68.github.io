﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.IO

Public Class Form1
    Dim pluginName As String
    Dim userName As String
    Dim version As String
    Dim finalDir As String
    Dim pluginFile As String
    Dim playerlistenerfile As String
    Dim blocklistenerfile As String
    Dim ymlfile As String
    Dim package As String
    Dim dotprojectfile, dotclasspathfile As String
    Dim output As String
    Dim hooks As String()
    Dim thisver As Integer = New IniParser("data/config.ini").getInt("template-ver")
    Private Function buildRegisterEvent(ByVal type As String, ByVal listener As String, ByVal priority As String) As String
        Dim sb As New StringBuilder("")
        sb.Append("pm.registerEvent(Event.Type.")
        sb.Append(type)
        sb.Append(",")
        sb.Append(listener)
        sb.Append(",Event.Priority.")
        sb.Append(priority)
        sb.Append(", this);")
        Return sb.ToString
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Retreive vars
        pluginName = TextBox2.Text
        userName = My.User.Name
        version = TextBox3.Text
        package = Package0.Text
        If pluginName = "" Or package = "" Then
            MsgBox("Please set up first")
            Return
        End If
        If version = "" Then
            version = "0.0"
        End If
        Dim packages As String() = package.Split(".")
        'avoid unwanted chars in userName and pluginName
        userName = userName.Replace("\", "_")
        userName = userName.Replace("/", "_")
        pluginName = pluginName.Replace("\", "_")
        pluginName = pluginName.Replace("/", "_")
        'Run setup to load variables
        tsetup()
        'Create main dirs
        My.Computer.FileSystem.CreateDirectory(output & "/" & pluginName)
        My.Computer.FileSystem.CreateDirectory(output & "/" & pluginName & "/src")
        My.Computer.FileSystem.CreateDirectory(output & "/" & pluginName & "/bin")
        'Create package dirs
        Dim finalDir As String = output & "/" & pluginName & "/src/"
        For Each s As String In packages
            finalDir = finalDir & "/" & s & "/"
            My.Computer.FileSystem.CreateDirectory(finalDir)
        Next
        'Final dir is package dir where the files are stored
        'Creating and writing to files
        My.Computer.FileSystem.WriteAllText(output & "/" & pluginName & "/" & "plugin.yml", ymlfile, False)
        My.Computer.FileSystem.WriteAllText(finalDir & "/" & pluginName & ".java", pluginFile, False)
        My.Computer.FileSystem.WriteAllText(finalDir & "/" & pluginName & "BlockListener.java", blocklistenerfile, False)
        My.Computer.FileSystem.WriteAllText(finalDir & "/" & pluginName & "PlayerListener.java", playerlistenerfile, False)
        'Create .classpath and .project for Eclipse usage
        My.Computer.FileSystem.WriteAllText(output & "/" & pluginName & "/.classpath", dotclasspathfile, False)
        My.Computer.FileSystem.WriteAllText(output & "/" & pluginName & "/.project", dotprojectfile, False)
        MsgBox("Operation done!Don't forget to add bukkit.jar file to build path in your IDE.")
    End Sub
    Public Sub tsetup()
        'Load template files
        pluginFile = My.Computer.FileSystem.ReadAllText("template/Plugin.tmp")
        blocklistenerfile = My.Computer.FileSystem.ReadAllText("template/BlockListener.tmp")
        playerlistenerfile = My.Computer.FileSystem.ReadAllText("template/PlayerListener.tmp")
        dotclasspathfile = My.Computer.FileSystem.ReadAllText("template/dClasspath.tmp")
        dotprojectfile = My.Computer.FileSystem.ReadAllText("template/dProject.tmp")
        ymlfile = My.Computer.FileSystem.ReadAllText("template/yml.tmp")
        'Parse template files
        pluginFile = pluginFile.Replace("~plugin~", pluginName)
        pluginFile = pluginFile.Replace("~package~", package)
        pluginFile = pluginFile.Replace("~user~", userName)
        If UseHooksCheck.Checked Then

            Dim hooks As String() = getAllHooks()
            Dim hookBuilder As New StringBuilder
            For Each s As String In hooks
                hookBuilder.Append(s & vbCrLf)
            Next
            pluginFile = pluginFile.Replace("~hooks~", hookBuilder.ToString)
            'The further features(writing functions to files)
            blocklistenerfile = blocklistenerfile.Replace("~custom~", "")
            playerlistenerfile = playerlistenerfile.Replace("~custom~", "")
        Else
            'Someone decided not to use HookAdder :(
            pluginFile = pluginFile.Replace("~hooks~", "")
            blocklistenerfile = blocklistenerfile.Replace("~custom~", "")
            playerlistenerfile = playerlistenerfile.Replace("~custom~", "")
        End If
        blocklistenerfile = blocklistenerfile.Replace("~plugin~", pluginName)
        blocklistenerfile = blocklistenerfile.Replace("~package~", package)
        blocklistenerfile = blocklistenerfile.Replace("~user~", userName)
        playerlistenerfile = playerlistenerfile.Replace("~plugin~", pluginName)
        playerlistenerfile = playerlistenerfile.Replace("~package~", package)
        playerlistenerfile = playerlistenerfile.Replace("~user~", userName)
        dotprojectfile = dotprojectfile.Replace("~plugin~", pluginName)
        ymlfile = ymlfile.Replace("~plugin~", pluginName)
        ymlfile = ymlfile.Replace("~package~", package)
        ymlfile = ymlfile.Replace("~version~", version)
        'Check for output dir
        If Not Label8.Text = "(output directory has not been set up)" Then
            output = Label8.Text
        Else
            My.Computer.FileSystem.CreateDirectory("output")
            output = "output"
        End If
    End Sub
    ' Hook adder
    Private Sub AddHookB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddHookB.Click
        If Not HookTypeBox.SelectedIndex = -1 And Not ListenerBox.SelectedIndex = -1 And Not PriorityBox.SelectedIndex = -1 Then
            ListBox1.Items.Add(HookTypeBox.SelectedItem)
            ListBox2.Items.Add(ListenerBox.SelectedItem)
            ListBox3.Items.Add(PriorityBox.SelectedItem)
        Else
            Return
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        'Protect application against unexpected and unwanted results
        If ListBox1.SelectedIndex = -1 Then
            Return
        End If
        ListBox2.SelectedIndex = ListBox1.SelectedIndex
        ListBox3.SelectedIndex = ListBox1.SelectedIndex
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        'Protect application against unexpected and unwanted results
        If ListBox2.SelectedIndex = -1 Then
            Return
        End If
        ListBox1.SelectedIndex = ListBox2.SelectedIndex
        ListBox3.SelectedIndex = ListBox2.SelectedIndex
    End Sub

    Private Sub ListBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox3.SelectedIndexChanged
        'Protect application against unexpected and unwanted results
        If ListBox3.SelectedIndex = -1 Then
            Return
        End If
        ListBox1.SelectedIndex = ListBox3.SelectedIndex
        ListBox2.SelectedIndex = ListBox3.SelectedIndex
    End Sub

    Private Sub RmHookB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RmHookB.Click
        'There's no reason to remove when you don't know what should you remove
        If ListBox1.SelectedIndex = -1 And ListBox2.SelectedIndex = -1 And ListBox3.SelectedIndex = -1 Then
            Return
        End If
        ListBox1.Items.RemoveAt(ListBox1.SelectedIndex)
        ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)
        ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
    End Sub
    Private Function getAllHooks() As String()
        Dim result(0 To ListBox1.Items.Count) As String
        Dim i As Short = 0
        For Each s As String In ListBox1.Items
            result(i) = buildRegisterEvent(ListBox1.Items.Item(i), ListBox2.Items.Item(i), ListBox3.Items.Item(i))
            i += 1
        Next
        Return result
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Load items for combo boxes (hook types,priorities)
        Try
            Dim line As String
            Dim readFile As System.IO.TextReader = New  _
    StreamReader("data/hooktypes.txt")
            While True
                line = readFile.ReadLine()
                If line Is Nothing Then
                    Exit While
                Else
                    HookTypeBox.Items.Add(line)
                End If
            End While
            readFile.Close()
            readFile = Nothing
        Catch ex As IOException
            MsgBox(ex.ToString)
        End Try
        'Load config
        Dim ip As New IniParser("data/config.ini")
        Label8.Text = ip.getString("output")
        output = Label8.Text
    End Sub
    'Browse to output path & save it to config
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        FolderBrowserDialog1.ShowDialog()
        Label8.Text = FolderBrowserDialog1.SelectedPath
        Dim ip As New IniParser("data/config.ini")
        ip.put("output", Label8.Text)
    End Sub
    'For adding custom listener(s)
    Private Sub ListenerBox_SelectedValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListenerBox.SelectedValueChanged
        If ListenerBox.SelectedItem = "custom..." Then
            ListenerBox.Items.Add(InputBox("Enter custom listener name"))
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim apppath As String = System.Reflection.Assembly.GetExecutingAssembly.Location
        My.Computer.FileSystem.CreateDirectory(apppath & "/temp")
        My.Computer.Network.DownloadFile("http://www.jaskovehry.tym.sk/bukkitpluginkit/template/ver.v", apppath & "/temp/version.v")
        Dim ver As String = My.Computer.FileSystem.ReadAllText(apppath & "/temp/version.v")
        Dim updatever As Integer = Integer.Parse(ver)
        If thisver < updatever Then
            Dim update As Boolean = MsgBox("Do you want to update from " & thisver & "to " & updatever & "?", MsgBoxStyle.OkCancel, "New version of template available")
            If update Then
                My.Computer.Network.DownloadFile("http://www.jaskovehry.tym.sk/bukkitpluginkit/template/template.zip", apppath & "/temp/template.zip")
                prepareTemplate(apppath & "/temp/template.zip")
                thisver = updatever
            End If
        End If
    End Sub
    Private Sub prepareTemplate(ByVal templateZipPath As String)

    End Sub
End Class
