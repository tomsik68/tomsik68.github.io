﻿Imports System.IO
Imports System.Text

Public Class IniParser
    Dim path As String
    Public Sub New(ByVal pathToIni As String)
        path = pathToIni
    End Sub
    Public Function getInt(ByVal key As String) As Integer
        Try
            Dim line As String
            Dim readFile As System.IO.TextReader = New  _
    StreamReader(path)
            While True
                line = readFile.ReadLine()
                If line Is Nothing Then
                    Exit While
                Else
                    If line.Contains(key) Then
                        readFile.Close()
                        Return Integer.Parse(line.Replace(key & "=", ""))
                    End If
                End If
            End While
            readFile.Close()
            readFile = Nothing
        Catch ex As IOException
            MsgBox(ex.ToString)
        End Try


    End Function
    Public Function getString(ByVal key As String) As String
        Try
            Dim line As String
            Dim readFile As System.IO.TextReader = New  _
    StreamReader(path)
            While True
                line = readFile.ReadLine()
                If line Is Nothing Then
                    Exit While
                Else
                    If line.Contains(key) Then
                        readFile.Close()
                        Return line.Replace(key & "=", "")
                    End If
                End If
            End While
            readFile.Close()
            readFile = Nothing
        Catch ex As IOException
            MsgBox(ex.ToString)
        End Try
        Return ""
    End Function
    Public Sub put(ByVal key As String, ByVal value As Object)
        Dim builder As New StringBuilder()
        Try
            Dim line As String
            Dim readFile As System.IO.TextReader = New  _
    StreamReader(path)
            While True
                line = readFile.ReadLine()
                If line Is Nothing Then
                    Exit While
                Else
                    If line.Contains(key) Then
                        readFile.Close()
                        line = key & "=" & value
                    End If
                    builder.Append(line)
                End If
            End While
            readFile.Close()
            readFile = Nothing
        Catch ex As IOException
            MsgBox(ex.ToString)
        End Try
        My.Computer.FileSystem.WriteAllText(path, builder.ToString, False)
    End Sub
End Class
