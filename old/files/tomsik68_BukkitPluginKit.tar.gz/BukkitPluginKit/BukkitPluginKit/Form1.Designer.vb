﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Label1 = New System.Windows.Forms.Label
        Me.Package0 = New System.Windows.Forms.TextBox
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.ListBox3 = New System.Windows.Forms.ListBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.HookTypeBox = New System.Windows.Forms.ComboBox
        Me.ListenerBox = New System.Windows.Forms.ComboBox
        Me.PriorityBox = New System.Windows.Forms.ComboBox
        Me.AddHookB = New System.Windows.Forms.Button
        Me.RmHookB = New System.Windows.Forms.Button
        Me.UseHooksCheck = New System.Windows.Forms.CheckBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.Button3 = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Plugin's name:"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(130, 6)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Version(optional):"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(130, 35)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(14, 400)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Generate project"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "bukkit.jar"
        Me.OpenFileDialog1.Filter = "JAR files(*.jar)|*.jar"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Package/Namespace"
        '
        'Package0
        '
        Me.Package0.Location = New System.Drawing.Point(130, 66)
        Me.Package0.Name = "Package0"
        Me.Package0.Size = New System.Drawing.Size(100, 20)
        Me.Package0.TabIndex = 8
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(5, 87)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 147)
        Me.ListBox1.TabIndex = 11
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(120, 87)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(120, 147)
        Me.ListBox2.TabIndex = 12
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(236, 87)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(120, 147)
        Me.ListBox3.TabIndex = 13
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(26, 71)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Hook"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(144, 71)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Listener"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(269, 71)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Priority"
        '
        'HookTypeBox
        '
        Me.HookTypeBox.FormattingEnabled = True
        Me.HookTypeBox.Location = New System.Drawing.Point(6, 20)
        Me.HookTypeBox.Name = "HookTypeBox"
        Me.HookTypeBox.Size = New System.Drawing.Size(121, 21)
        Me.HookTypeBox.TabIndex = 17
        Me.HookTypeBox.Text = "Hook Type"
        '
        'ListenerBox
        '
        Me.ListenerBox.FormattingEnabled = True
        Me.ListenerBox.Items.AddRange(New Object() {"playerListener", "blockListener", "custom..."})
        Me.ListenerBox.Location = New System.Drawing.Point(133, 20)
        Me.ListenerBox.Name = "ListenerBox"
        Me.ListenerBox.Size = New System.Drawing.Size(121, 21)
        Me.ListenerBox.TabIndex = 18
        Me.ListenerBox.Text = "Listener"
        '
        'PriorityBox
        '
        Me.PriorityBox.FormattingEnabled = True
        Me.PriorityBox.Items.AddRange(New Object() {"Lowest", "Low", "Normal", "High", "Highest", "Monitor"})
        Me.PriorityBox.Location = New System.Drawing.Point(260, 20)
        Me.PriorityBox.Name = "PriorityBox"
        Me.PriorityBox.Size = New System.Drawing.Size(121, 21)
        Me.PriorityBox.TabIndex = 19
        Me.PriorityBox.Text = "Priority"
        '
        'AddHookB
        '
        Me.AddHookB.Location = New System.Drawing.Point(6, 47)
        Me.AddHookB.Name = "AddHookB"
        Me.AddHookB.Size = New System.Drawing.Size(75, 23)
        Me.AddHookB.TabIndex = 20
        Me.AddHookB.Text = "Add Hook"
        Me.AddHookB.UseVisualStyleBackColor = True
        '
        'RmHookB
        '
        Me.RmHookB.Location = New System.Drawing.Point(87, 47)
        Me.RmHookB.Name = "RmHookB"
        Me.RmHookB.Size = New System.Drawing.Size(101, 23)
        Me.RmHookB.TabIndex = 21
        Me.RmHookB.Text = "Remove Hook"
        Me.RmHookB.UseVisualStyleBackColor = True
        '
        'UseHooksCheck
        '
        Me.UseHooksCheck.AutoSize = True
        Me.UseHooksCheck.Location = New System.Drawing.Point(6, 240)
        Me.UseHooksCheck.Name = "UseHooksCheck"
        Me.UseHooksCheck.Size = New System.Drawing.Size(102, 17)
        Me.UseHooksCheck.TabIndex = 22
        Me.UseHooksCheck.Text = "Use hook adder"
        Me.UseHooksCheck.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(97, 376)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(183, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "(output directory has not been set up)"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(14, 371)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(68, 23)
        Me.Button2.TabIndex = 24
        Me.Button2.Text = "Output..."
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RmHookB)
        Me.GroupBox1.Controls.Add(Me.AddHookB)
        Me.GroupBox1.Controls.Add(Me.PriorityBox)
        Me.GroupBox1.Controls.Add(Me.UseHooksCheck)
        Me.GroupBox1.Controls.Add(Me.ListenerBox)
        Me.GroupBox1.Controls.Add(Me.HookTypeBox)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.ListBox3)
        Me.GroupBox1.Controls.Add(Me.ListBox2)
        Me.GroupBox1.Controls.Add(Me.ListBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 92)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(406, 260)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Hook Adder"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(388, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(102, 23)
        Me.Button3.TabIndex = 26
        Me.Button3.Text = "Update template"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 436)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Package0)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "Bukkit Plugin Development kit"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Package0 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents HookTypeBox As System.Windows.Forms.ComboBox
    Friend WithEvents ListenerBox As System.Windows.Forms.ComboBox
    Friend WithEvents PriorityBox As System.Windows.Forms.ComboBox
    Friend WithEvents AddHookB As System.Windows.Forms.Button
    Friend WithEvents RmHookB As System.Windows.Forms.Button
    Friend WithEvents UseHooksCheck As System.Windows.Forms.CheckBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
