#include <stdio.h>
#include <stdlib.h>
#include<nds/input.h>
#include<nds/ndstypes.h>
#include "forceWifi.h"

int main(void) {
	Wifi_AccessPoint ap;
	consoleDemoInit();
	Wifi_InitDefault(true);
	Wifi_EnableWifi();
	while (1) {
		printf("Looking for WiFi networks... \n");
		printf("Number of APs found: %i\n", Wifi_GetNumAP());
		consoleClear();
		ap = Wifi_UserSelectAP();
		while (!(keysDown() & KEY_B)) {
			Wifi_displayApInfo(ap);
			wait(5);
			scanKeys();
			if (keysDown() & KEY_X) {
				printf("Key to WiFi is: %s \n", Wifi_GetWepKey(ap));
			}
		}
	}

	return 0;
}

