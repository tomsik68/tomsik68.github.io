#define ARM9
#include <nds.h>
#include <nds/ndstypes.h>
#include "wifi.h"
#include <stdio.h>
#include "charTools.h"
#include <string.h>
#include <nds/arm9/console.h>
#include <nds/arm9/input.h>
#include <nds/input.h>

unsigned char * Wifi_GetWepKey(Wifi_AccessPoint ap);
