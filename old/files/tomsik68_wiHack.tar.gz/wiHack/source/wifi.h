#ifndef __WIFI_H
#define __WIFI_H
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <nds.h>
#include <dswifi9.h>

void Wifi_displayApInfo(Wifi_AccessPoint ap);
Wifi_AccessPoint Wifi_UserSelectAP(void) ;
void Wifi_ListAp(int selected);
bool Wifi_UpdateSpotByName(char*name, Wifi_AccessPoint * ap);
void myWait(int msecs);
#endif
