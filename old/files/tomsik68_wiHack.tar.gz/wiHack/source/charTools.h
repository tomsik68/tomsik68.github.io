signed char unsignedToSigned(unsigned char c) {
	signed char s = c - 128;
	return s;
}
unsigned char signedToUnsigned(signed char c) {
	unsigned char u = c + 128;
	return u;
}
signed char *unsignedToSignedArray(unsigned char* c, int length) {
	signed char s[length];
	int i;
	for (i = 0; i < length; i++) {
		s[i] = unsignedToSigned(c[i]);
	}
	return s;
}

unsigned char *signedToUnsignedArray(signed char* c, int length) {
	unsigned char u[length];
	int i;
	for (i = 0; i < length; i++) {
		u[i] = signedToUnsigned(c[i]);
	}
	return u;
}

