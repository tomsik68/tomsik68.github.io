/*
 * wifi.cpp
 *
 *  Created on: 8.1.2012
 *      Author: Tomi
 */
#include "wifi.h"

void Wifi_displayApInfo(Wifi_AccessPoint ap) {
	consoleClear();
	printf(
			"SSID:%s \n Encryption:%s \n Sig:%i\n Network type:%s \n",
			ap.ssid,
			ap.flags & WFLAG_APDATA_WEP ? "WEP " :
			WFLAG_APDATA_WPA ? "WPA " : "No", ap.rssi * 100 / 0xD0,
			WFLAG_APDATA_ADHOC ? "Infrastructure" : "Ad-hoc");
}
Wifi_AccessPoint Wifi_UserSelectAP(void) {
	//---------------------------------------------------------------------------------

	int selected = 0;
	int i;
	int count = 0;

	static Wifi_AccessPoint ap;

	Wifi_ScanMode(); //this allows us to search for APs

	while (!(keysDown() & KEY_A)) {
		//find out how many APs there are in the area
		count = Wifi_GetNumAP();

		consoleClear();

		printf("Number of APs found: %d\n", count);

		//display the APs to the user
		for (i = 0; i < count; i++) {
			Wifi_AccessPoint ap;

			Wifi_GetAPData(i, &ap);
			// display the name of the AP
			printf(
					"%s %s Lock:%s Sig:%i\n",
					selected == i ? ">" : "*",
					ap.ssid,
					ap.flags & WFLAG_APDATA_WEP ? "WEP " :
					WFLAG_APDATA_WPA ? "WPA" : "None", ap.rssi * 100 / 0xD0);

		}
		scanKeys();
		//move the selection asterick
		if (keysDown() & KEY_UP) {
			selected--;
			if (selected < 0) {
				selected = 0;
			}
		}

		if (keysDown() & KEY_DOWN) {
			selected++;
			if (selected >= count) {
				selected = count - 1;
			}
		}
		wait(5);
	}

	//user has made a choice so grab the ap and return it
	Wifi_GetAPData(selected, &ap);

	return ap;
}

void Wifi_ListAp(int selected) {
	int i;
	int count = 0;
	char ** apName;
	Wifi_AccessPoint temp;
	Wifi_ScanMode(); //this allows us to search for APs
	//find out how many APs there are in the area
	count = Wifi_GetNumAP();
	//display the APs to the user
	printf("SSID | Encryption | Signal \n");
	for (i = 0; i < count; i++) {
		Wifi_GetAPData(i, &temp);
		printf(
				" |%s| %s | %s | %d \n",
				selected == i ? ">" : "*",
				temp.ssid,
				temp.flags & WFLAG_APDATA_WEP ? "WEP" :
				temp.flags & WFLAG_APDATA_WPA ? "WPA" : "None",
				temp.rssi * 100 / 0xD0);

	}
}
bool Wifi_UpdateSpotByName(char*name, Wifi_AccessPoint * ap) {
	Wifi_AccessPoint a;
	Wifi_ScanMode();
	int aps = Wifi_GetNumAP();
	int i;
	for (i = 0; i < aps; i++) {
		Wifi_GetAPData(i, &a);
		if (a.ssid == name) {
			Wifi_GetAPData(i, ap);
			return true;
		}
	}
	return false;
}



