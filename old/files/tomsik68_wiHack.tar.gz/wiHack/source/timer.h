#include <nds.h>
void wait(int msecs) {
	int i = 0;
	for (; i <= msecs; i++) {
		swiWaitForVBlank();
	}
}
