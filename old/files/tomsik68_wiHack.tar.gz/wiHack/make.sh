# !bin/sh
export DEVKITPRO=~/devkitPro
export DEVKITARM=$DEVKITPRO/devkitARM
make
