#include <PA9.h>
#include "gfx/all_gfx.h"
#include "gfx/all_gfx.c"
#include "include/rectangleCollision.h"
#include "include/point.h"
#define KROK 3

Tpoint mario; 
//cakanie
void wait(float miliseconds){
   int time;
   for(time=0;time<=miliseconds;time++){
	   PA_WaitForVBL();
}		   
}	   


   
//hlavna metoda
int main(){
   PA_Init();
   PA_InitVBL();
   PA_InitText(1,0);
   PA_EasyBgLoad(0,0,world);
   PA_LoadSpritePal(0,0,(void*)Mario_Pal);
   PA_LoadSpritePal(0,1,(void*)Shot_Pal);
   PA_LoadSpritePal(0,2,(void*)Enemy_Pal);
   PA_CreateSprite(0,0,(void*)mario_Sprite,OBJ_SIZE_16X32,1,0,0,0);
   while(1){
      PA_MoveSprite(0);
		controlLoop();
		if(!checkCollision(mario.x,mario.y,0,156,16,32,512,1)){
		   mario.y+=1;
		   wait(0.01);
		}   
		if(Pad.Newpress.Up)skok(48);
		PA_SetSpriteXY(0,0,mario.x,mario.y);
		PA_OutputText(1,0,0,"X: %d",mario.x);
		PA_OutputText(1,0,1,"Y: %d",PA_GetSpriteY(0,0));
		PA_WaitForVBL();
   }
   return 0;
}   
