#include <PA9.h>
#ifndef __LEVELS_H__
#define __LEVELS_H__
#define SAVE_FILE "/Mijo.sav"
#include "types.h"
level loadLevel(char*filename){
//declare myLevel to return it
level myLevel;

// FAT initialization
fatInitDefault();

// WB trunacates write and create. This will be used to create and write to the save file.
FILE* save_file = fopen(filename, "rb");

// Write save_data to save_file don't forget the & for save_data
fread(&myLevel, 1, sizeof(myLevel), save_file);
// Close the file
fclose(save_file);
return myLevel;
}

bool saveGame(save_struct save_data){
	if(fatInitDefault())
	{
	// WB trunacates write and create. This will be used to create and write to the save file.
	FILE* save_file = fopen(SAVE_FILE, "wb");

	// Write save_data to save_file don't forget the & for save_data
	fwrite(&save_data, 1, sizeof(save_data), save_file);

	// Close the file
	fclose(save_file);
	return true;
	}else{
 	return false;
}
}
#endif
