#include <PA9.h>
#include "types.h"
#include "gfx/all_gfx.h"
#include "gfx/all_gfx.c"
#include "level_loader.h"
#include "include/rectangleCollision.h"

plaver player;
Tmain _main;

void controlLoop(){
	if(Pad.Held.Left){
	player.x -= 1;
	PA_SetSpriteHflip(0,0,1);
	}
	if(Pad.Held.Right){
	player.x += 1;
    PA_SetSpriteHflip(0,0,0);
	}
	if(player.y < 176 - 16){
	player.y += 1;
	}
	PA_OutputText(1,0,0,"Stylus X : %d  \n Stylus Y : %d", Stylus.X, Stylus.Y);
	//kontrola skoku
	if(Pad.Newpress.A && player.jump == 0){
	player.jump = 48;
	 player.y-=1;
	 player.jump -= 1;
    }
	if(player.jump > 0){
	player.y-=1;
	player.jump -= 1;
	}

    PA_SetSpriteXY(0,0,player.x,player.y);
	PA_WaitForVBL();
}
int main(){
   PA_Init();
	PA_InitText(1,0);
	PA_LoadSpritePal(0,0,(void*)Jaskova_Pal);
 	loadLevel("level1.mio");
 
	while(1){
	}
   return 0;
}   
