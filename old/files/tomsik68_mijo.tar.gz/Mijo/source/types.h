#include <PA9.h>
#ifndef __TYPES_H__
#define __TYPES_H__

#define DIAMOND_W 8
#define DIAMOND_H 8

typedef struct
{
s16 x;
s16 y;
u8 jump;
u8 lives;
}plaver;

typedef struct
{
u8 score;
}Tmain;

typedef struct
{
s16 x;
s16 y;
u8 w;
u8 h;
}collisionRectangle;
typedef struct{
char*level_name;
collisionRectangle*diamonds;
collisionRectangle*ground;
}level;
typedef struct{
int lives;
int level;
}save_struct;
#endif
